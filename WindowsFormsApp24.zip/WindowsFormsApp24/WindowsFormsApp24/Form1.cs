﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp24
{
    public abstract class Pair
    {
        public abstract Pair Add(Pair p);
        public abstract Pair Subtract(Pair p);
        public abstract Pair Multiply(Pair p);
        public abstract Pair Divide(Pair p);
    }
    public class Money : Pair
    {
        private int _dollars;
        private int _cents;
        public Money(int dollars, int cents)
        {
            _dollars = dollars;
            _cents = cents;
        }
        public override Pair Add(Pair p)
        {
            Money m = (Money)p;
            int totalCents = _cents + m._cents;
            int carryOver = totalCents / 100;
            int cents = totalCents % 100;
            int dollars = _dollars + m._dollars + carryOver;
            return new Money(dollars, cents);
        }
        public override Pair Subtract(Pair p)
        {
            Money m = (Money)p;
            int totalCents = _cents - m._cents;
            int borrow = 0;
            if (totalCents < 0)
            {
                borrow = 1;
                totalCents += 100;
            }
            int dollars = _dollars - m._dollars - borrow;
            return new Money(dollars, totalCents);
        }
        public override Pair Multiply(Pair p)
        {
            Money m = (Money)p;
            int totalCents = (_dollars * 100 + _cents) * (m._dollars * 100 + m._cents);
            int dollars = totalCents / 10000;
            int cents = totalCents % 100;
            return new Money(dollars, cents);
        }
        public override Pair Divide(Pair p)
        {
            Money m = (Money)p;
            int totalCents1 = _dollars * 100 + _cents;
            int totalCents2 = m._dollars * 100 + m._cents;
            int dollars = totalCents1 / totalCents2;
            int cents = (totalCents1 % totalCents2) / 100;
            return new Money(dollars, cents);
        }
        public override string ToString()
        {
            return "$" + _dollars + "." + _cents.ToString("00");
        }
    }
    public class Fraction : Pair
    {
        private int _numerator;
        private int _denominator;
        public Fraction(int numerator, int denominator)
        {
            _numerator = numerator;
            _denominator = denominator;
        }
        public override Pair Add(Pair p)
        {
            Fraction f = (Fraction)p;
            int lcm = LCM(_denominator, f._denominator);
            int numerator1 = _numerator * (lcm / _denominator);
            int numerator2 = f._numerator * (lcm / f._denominator);
            int numerator = numerator1 + numerator2;
            int denominator = lcm;
            return Simplify(new Fraction(numerator, denominator));
        }
        public override Pair Subtract(Pair p)
        {
            Fraction f = (Fraction)p;
            int lcm = LCM(_denominator, f._denominator);
            int numerator1 = _numerator * (lcm / _denominator);
            int numerator2 = f._numerator * (lcm / f._denominator);
            int numerator = numerator1 - numerator2;
            int denominator = lcm;
            return Simplify(new Fraction(numerator, denominator));
        }
        public override Pair Multiply(Pair p)
        {
            Fraction f = (Fraction)p;
            int numerator = _numerator * f._numerator;
            int denominator = _denominator * f._denominator;
            return Simplify(new Fraction(numerator, denominator));
        }
        public override Pair Divide(Pair p)
        {
            Fraction f = (Fraction)p;
            int numerator = _numerator * f._denominator;
            int denominator = _denominator * f._numerator;
            return Simplify(new Fraction(numerator, denominator));
        }
        private int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;

            }
            return a;
        }
        private int LCM(int a, int b)
        {
            return a * b / GCD(a, b);
        }
        private Fraction Simplify(Fraction f)
        {
            int gcd = GCD(f._numerator, f._denominator);
            return new Fraction(f._numerator / gcd, f._denominator / gcd);
        }
        public override string ToString()
        {
            if (_denominator == 1)
            {
                return _numerator.ToString();
            }
            else
            {
                return _numerator + "/" + _denominator;
            }
        }
    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Pair p1 = GetPair(textBox1.Text);
            Pair p2 = GetPair(textBox2.Text);
            Pair result = p1.Add(p2);
            textBox3.Text = result.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Pair p1 = GetPair(textBox1.Text);
            Pair p2 = GetPair(textBox2.Text);
            Pair result = p1.Subtract(p2);
            textBox4.Text = result.ToString();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Pair p1 = GetPair(textBox1.Text);
            Pair p2 = GetPair(textBox2.Text);
            Pair result = p1.Multiply(p2);
            textBox5.Text = result.ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Pair p1 = GetPair(textBox1.Text);
            Pair p2 = GetPair(textBox2.Text);
            Pair result = p1.Divide(p2);
            textBox6.Text = result.ToString();

        }
        private Pair GetPair(string input)
        {
            string[] parts = input.Split('/');
            if (parts.Length == 1)
            {
                int value = int.Parse(parts[0]);
                return new Fraction(value, 1);
            }
            else if (parts.Length == 2)
            {
                int numerator = int.Parse(parts[0]);
                int denominator = int.Parse(parts[1]);
                return new Fraction(numerator, denominator);
            }
            else if (input.Contains("."))
            {
                string[] dollarsAndCents = input.Split('.');
                int dollars = int.Parse(dollarsAndCents[0]);
                int cents = int.Parse(dollarsAndCents[1]);
                return new Money(dollars, cents);
            }
            else
            {
                int value = int.Parse(input);
                return new Fraction(value, 1);
            }

        }
    }
}